package com.example.service;

import org.springframework.stereotype.Service;

@Service
public class SqlSolverService {
    
    public boolean isOddQuestion(String regNo) {
        try {
            int lastDigit = Integer.parseInt(regNo.substring(regNo.length() - 1));
            return lastDigit % 2 == 1;
        } catch (Exception e) {
            return true;
        }
    }
    
    public String getQuestion1Query() {
        return """
            SELECT 
                p.AMOUNT AS SALARY,
                CONCAT(e.FIRST_NAME, ' ', e.LAST_NAME) AS NAME,
                TIMESTAMPDIFF(YEAR, e.DOB, CURDATE()) AS AGE,
                d.DEPARTMENT_NAME
            FROM PAYMENTS p
            INNER JOIN EMPLOYEE e ON p.EMP_ID = e.EMP_ID
            INNER JOIN DEPARTMENT d ON e.DEPARTMENT = d.DEPARTMENT_ID
            WHERE DAY(p.PAYMENT_TIME) != 1
            ORDER BY p.AMOUNT DESC
            LIMIT 1
            """;
    }
    
    public String getQuestion2Query() {
        return """
            SELECT 
                e1.EMP_ID,
                e1.FIRST_NAME,
                e1.LAST_NAME,
                d.DEPARTMENT_NAME,
                COUNT(e2.EMP_ID) AS YOUNGER_EMPLOYEES_COUNT
            FROM EMPLOYEE e1
            INNER JOIN DEPARTMENT d ON e1.DEPARTMENT = d.DEPARTMENT_ID
            LEFT JOIN EMPLOYEE e2 ON e1.DEPARTMENT = e2.DEPARTMENT 
                AND e2.DOB > e1.DOB
            GROUP BY e1.EMP_ID, e1.FIRST_NAME, e1.LAST_NAME, d.DEPARTMENT_NAME
            ORDER BY e1.EMP_ID DESC
            """;
    }
    
    public String solveProblem(String regNo) {
        if (isOddQuestion(regNo)) {
            System.out.println("Solving Question 1 (Odd regNo): Highest salary not on 1st day");
            return getQuestion1Query();
        } else {
            System.out.println("Solving Question 2 (Even regNo): Count younger employees by department");
            return getQuestion2Query();
        }
    }
}