package com.example.service;

import com.example.model.SolutionRequest;
import com.example.model.WebhookRequest;
import com.example.model.WebhookResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WebhookService {
    
    private static final String GENERATE_WEBHOOK_URL = 
        "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";
    
    @Autowired
    private SqlSolverService sqlSolverService;
    
    private final RestTemplate restTemplate;
    
    public WebhookService() {
        this.restTemplate = new RestTemplate();
    }
    
    public WebhookResponse generateWebhook() {
        try {
            WebhookRequest request = new WebhookRequest(
                "Suvarsha", 
                "22BCE7421", 
                "gaddamsuvarsha@gmail.com"
            );
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            
            HttpEntity<WebhookRequest> entity = new HttpEntity<>(request, headers);
            
            System.out.println("Sending POST request to generate webhook...");
            ResponseEntity<WebhookResponse> response = restTemplate.postForEntity(
                GENERATE_WEBHOOK_URL, 
                entity, 
                WebhookResponse.class
            );
            
            WebhookResponse webhookResponse = response.getBody();
            if (webhookResponse != null) {
                System.out.println("Webhook generated successfully!");
                System.out.println("Webhook URL: " + webhookResponse.getWebhook());
                return webhookResponse;
            } else {
                throw new RuntimeException("Failed to generate webhook - null response");
            }
            
        } catch (Exception e) {
            System.err.println("Error generating webhook: " + e.getMessage());
            throw new RuntimeException("Failed to generate webhook", e);
        }
    }
    
    public void submitSolution(String webhookUrl, String accessToken, String sqlQuery) {
        try {
            SolutionRequest solution = new SolutionRequest(sqlQuery);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", accessToken);
            
            HttpEntity<SolutionRequest> entity = new HttpEntity<>(solution, headers);
            
            System.out.println("Submitting solution to webhook...");
            System.out.println("SQL Query: " + sqlQuery);
            
            ResponseEntity<String> response = restTemplate.postForEntity(
                webhookUrl, 
                entity, 
                String.class
            );
            
            if (response.getStatusCode().is2xxSuccessful()) {
                System.out.println("Solution submitted successfully!");
                System.out.println("Response: " + response.getBody());
            }
            
        } catch (Exception e) {
            System.err.println("Error submitting solution: " + e.getMessage());
            throw new RuntimeException("Failed to submit solution", e);
        }
    }
}