package com.example.startup;

import com.example.model.WebhookResponse;
import com.example.service.SqlSolverService;
import com.example.service.WebhookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class StartupRunner implements CommandLineRunner {
    
    @Autowired
    private WebhookService webhookService;
    
    @Autowired
    private SqlSolverService sqlSolverService;
    
    @Override
    public void run(String... args) throws Exception {
        System.out.println("=== Starting Webhook SQL Solver Application ===");
        
        try {
            System.out.println("\nStep 1: Generating webhook...");
            WebhookResponse webhookResponse = webhookService.generateWebhook();
            
            System.out.println("\nStep 2: Solving SQL problem...");
            String regNo = "22BCE7421";
            String sqlSolution = sqlSolverService.solveProblem(regNo);
            
            System.out.println("\nStep 3: Submitting solution...");
            webhookService.submitSolution(
                webhookResponse.getWebhook(),
                webhookResponse.getAccessToken(),
                sqlSolution
            );
            
            System.out.println("\n=== Process completed successfully! ===");
            
        } catch (Exception e) {
            System.err.println("Error during startup process: " + e.getMessage());
            e.printStackTrace();
        }
    }
}